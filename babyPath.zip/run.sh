sudo python3 babyPath.py &
sudo python3 -m http.server 8080 &
